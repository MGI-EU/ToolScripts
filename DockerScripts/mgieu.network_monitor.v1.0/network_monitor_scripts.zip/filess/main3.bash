#!/bin/bash
cd /filess/filess
./main2.bash
