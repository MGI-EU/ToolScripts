nohup ./main.bash >> out.txt 2>&1 &
